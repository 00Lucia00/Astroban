public class Highscores {
}
